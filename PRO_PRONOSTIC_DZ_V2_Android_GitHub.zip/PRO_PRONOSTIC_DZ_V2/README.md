# PRO PRONOSTIC DZ — projet Android

Application de démonstration Android bilingue français / arabe.

## Créer gratuitement l'APK depuis un téléphone avec GitHub Actions

1. Créez un compte gratuit sur https://github.com si vous n'en avez pas.
2. Sur GitHub, créez un nouveau dépôt (repository), par exemple `PRO-PRONOSTIC-DZ`.
3. Téléversez **tout le contenu** de ce dossier dans le dépôt, en conservant les dossiers `.github/workflows` et `app`.
4. Ouvrez l'onglet **Actions** du dépôt.
5. Choisissez **Construire APK Android**, puis **Run workflow** et confirmez.
6. Attendez que l'exécution soit terminée avec une coche verte.
7. Ouvrez cette exécution et téléchargez l'élément **PRO-PRONOSTIC-DZ-APK** dans la section Artifacts.
8. Décompressez le fichier téléchargé : vous trouverez `app-debug.apk`. Ouvrez-le sur votre téléphone pour l'installer. Android peut demander d'autoriser l'installation depuis cette source.

La compilation et le téléchargement de l'APK de test sont gratuits dans les limites du forfait GitHub Actions.

## Important

- Cet APK est une **version debug de test**, pas une version signée pour publication sur Google Play.
- Les matchs, équipes, heures et pourcentages affichés dans la version actuelle sont des exemples fictifs. Ils ne constituent pas des pronostics en direct.
- Pour de véritables analyses automatiques, il faudra connecter une API de données football et développer un modèle statistique fiable.
- Aucun pari ni dépôt d'argent n'est intégré à l'application.
