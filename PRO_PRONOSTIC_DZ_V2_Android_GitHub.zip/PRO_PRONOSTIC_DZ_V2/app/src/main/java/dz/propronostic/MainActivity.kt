package dz.propronostic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B293B)
private val Green = Color(0xFF19C37D)
private val Muted = Color(0xFF9EADBE)

private data class MatchTip(
    val league: String, val home: String, val away: String,
    val time: String, val pickFr: String, val pickAr: String,
    val confidence: Int
)

// Démonstration : fixtures et chiffres fictifs, non connectés à une API en direct.
private val demoMatches = listOf(
    MatchTip("Ligue 1", "Équipe A", "Équipe B", "18:00", "Moins de 3,5 buts", "أقل من 3.5 أهداف", 72),
    MatchTip("Premier League", "Équipe C", "Équipe D", "20:00", "Les deux équipes : NON", "كلا الفريقين لا يسجلان", 64),
    MatchTip("La Liga", "Équipe E", "Équipe F", "Demain · 19:30", "Double chance 1X", "فرصة مزدوجة 1X", 69),
    MatchTip("Serie A", "Équipe G", "Équipe H", "Demain · 21:00", "Moins de 4,5 buts", "أقل من 4.5 أهداف", 76),
    MatchTip("Ligue 1 Algérie", "Équipe I", "Équipe J", "À confirmer", "Analyse en attente", "التحليل قيد الانتظار", 0)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ProPronosticApp() }
    }
}

@Composable
private fun ProPronosticApp() {
    var arabic by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = if (arabic) listOf("المباريات", "الإحصائيات", "حول") else listOf("Matchs", "Statistiques", "À propos")

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Navy, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Navy).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("PRO PRONOSTIC DZ", color = Green, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text(if (arabic) "تحليلات وإحصائيات كرة القدم" else "ANALYSES & STATISTIQUES FOOTBALL",
                        color = Muted, fontSize = 10.sp)
                }
                TextButton(onClick = { arabic = !arabic }) {
                    Text(if (arabic) "FR" else "عربي", color = Green, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                tabs.forEachIndexed { index, title ->
                    FilterChip(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        label = { Text(title, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Green, selectedLabelColor = Navy
                        )
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            when (selectedTab) {
                0 -> {
                    Text(if (arabic) "توقعات تجريبية" else "Analyses des matchs", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(if (arabic) "بيانات توضيحية وليست مباشرة" else "Données de démonstration — pas de flux en direct",
                        color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(demoMatches) { item -> MatchCard(item, arabic) }
                    }
                }
                1 -> {
                    Text(if (arabic) "إحصائيات البطولات" else "Statistiques des championnats",
                        fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(if (arabic) "سيتم عرض الترتيب والنتائج بعد ربط مصدر بيانات رياضي موثوق."
                        else "Les classements, résultats et statistiques seront affichés après connexion à une source de données sportives fiable.",
                        color = Muted)
                }
                else -> {
                    Text(if (arabic) "حول التطبيق" else "À propos", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(if (arabic) "تطبيق مجاني لتحليل كرة القدم. التوقعات احتمالات إحصائية وليست ضماناً للنتائج."
                        else "Application gratuite d'analyse du football. Les prédictions sont des estimations statistiques et ne garantissent aucun résultat.",
                        color = Muted)
                }
            }
            Spacer(Modifier.weight(1f))
            Text(
                if (arabic) "للمعلومات فقط. لا تراهن بأموال لا يمكنك تحمل خسارتها."
                else "Information uniquement. Les estimations ne garantissent aucun résultat.",
                color = Muted, fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun MatchCard(item: MatchTip, arabic: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(item.league.uppercase(), color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f))
                Text(item.time, color = Muted, fontSize = 10.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text("${item.home}  vs  ${item.away}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (arabic) "اقتراح تجريبي" else "SUGGESTION DÉMO", color = Muted, fontSize = 9.sp)
                    Text(if (arabic) item.pickAr else item.pickFr, fontWeight = FontWeight.SemiBold)
                }
                if (item.confidence > 0) {
                    Text("${item.confidence}%", color = Green, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                } else {
                    Text("—", color = Muted, fontSize = 20.sp)
                }
            }
        }
    }
}
